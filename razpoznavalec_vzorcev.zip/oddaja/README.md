# Oddaja razpoznavalca vzorcev

- Pri oddaji sem datoteke formatiral kot v navodilu, sicer sem več loss grafov dal v direktorij /tensorboard_loss
- imel sem tudi pripravljen originalna_koda_ki_ni_formatirana_za_oddajo.zip, ki je moja originalna koda zgledala, pred formatiranjem za oddajo, a zaradi velikosti (brez fotografij) ni šlo oddati. Če je treba vam lahko kodo pri vajah ali ob dogovoru pokažem. Moj mail je nikola.popovski@student.um.si